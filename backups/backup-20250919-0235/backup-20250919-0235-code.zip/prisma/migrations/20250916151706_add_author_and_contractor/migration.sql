-- AlterTable
ALTER TABLE "public"."Offer" ADD COLUMN     "authorInitials" TEXT,
ADD COLUMN     "contractor" TEXT;
