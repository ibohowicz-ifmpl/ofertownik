// src/app/api/offers/[id]/note/route.ts
import { prisma } from "@/lib/prisma";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const offer = await prisma.offer.findUnique({
    where: { id },
    select: { note: true },
  });
  return Response.json({ note: offer?.note ?? "" });
}

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  let body: any;
  try {
    body = await req.json();
  } catch {
    return new Response("Invalid JSON", { status: 400 });
  }
  const note: string = typeof body?.note === "string" ? body.note : "";
  const updated = await prisma.offer.update({
    where: { id },
    data: { note },
    select: { note: true },
  });
  return Response.json({ ok: true, note: updated.note ?? "" });
}
