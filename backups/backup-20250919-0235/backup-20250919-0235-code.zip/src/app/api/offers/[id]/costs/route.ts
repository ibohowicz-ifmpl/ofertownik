// src/app/api/offers/[id]/costs/route.ts
import { prisma } from "@/lib/prisma";

function toStrMoney(v: unknown): string {
  // akceptujemy number lub string z przecinkiem/kropką
  if (typeof v === "number") return v.toFixed(2);
  if (typeof v === "string") {
    const s = v.replace(",", ".").trim();
    const n = Number(s);
    if (Number.isFinite(n)) return n.toFixed(2);
  }
  throw new Error("Invalid money value");
}

export async function GET(_req: Request, context: { params: Promise<{ id: string }> }) {
  const { id: offerId } = await context.params;
  const items = await prisma.offerCost.findMany({
    where: { offerId },
    orderBy: { createdAt: "asc" },
    take: 5,
    select: { id: true, name: true, valueNet: true },
  });

  const plain = items.map((it) => ({
    id: it.id,
    name: it.name,
    valueNet: Number(it.valueNet), // Decimal -> number
  }));
  const sum = plain.reduce((a, b) => a + (b.valueNet || 0), 0);

  return Response.json({ items: plain, sum });
}

export async function PUT(req: Request, context: { params: Promise<{ id: string }> }) {
  const { id: offerId } = await context.params;
  const body = await req.json().catch(() => ({}));
  let items = Array.isArray(body?.items) ? body.items : [];

  // limit do 5 oraz walidacja
  items = items
    .slice(0, 5)
    .map((raw, idx) => {
      const name = (raw?.name ?? "").toString().trim();
      const rawVal = raw?.valueNet;
      if (!name && (rawVal === null || rawVal === undefined || rawVal === "")) {
        // pusta linia – pomijamy
        return null;
      }
      if (!name) throw new Error(`Wiersz ${idx + 1}: podaj nazwę kosztu`);
      const valueStr = toStrMoney(rawVal);
      return { name, valueStr };
    })
    .filter(Boolean) as { name: string; valueStr: string }[];

  // transakcja: nadpisujemy koszty danego offerId
  const result = await prisma.$transaction(async (tx) => {
    await tx.offerCost.deleteMany({ where: { offerId } });

    if (items.length > 0) {
      await tx.offerCost.createMany({
        data: items.map((it) => ({
          offerId,
          name: it.name,
          valueNet: it.valueStr, // Decimal jako string
        })),
      });
    }

    // wyliczamy sumę i zapisujemy do Offer.wartoscKosztow (dla listy/analityki)
    const agg = await tx.offerCost.aggregate({
      where: { offerId },
      _sum: { valueNet: true },
    });
    const sumDec = agg._sum.valueNet ?? 0;
    await tx.offer.update({
      where: { id: offerId },
      data: { wartoscKosztow: sumDec },
    });

    const saved = await tx.offerCost.findMany({
      where: { offerId },
      orderBy: { createdAt: "asc" },
      take: 5,
      select: { id: true, name: true, valueNet: true },
    });

    return {
      items: saved.map((it) => ({ id: it.id, name: it.name, valueNet: Number(it.valueNet) })),
      sum: Number(sumDec),
    };
  });

  return Response.json(result);
}
