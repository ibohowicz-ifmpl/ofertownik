// src/app/offers/[id]/infoPanel.tsx
"use client";

import { useEffect, useState, useMemo } from "react";

export default function InfoPanel({ offerId }: { offerId: string }) {
  const [note, setNote] = useState("");
  const [baseline, setBaseline] = useState("");
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  const dirty = useMemo(() => note !== baseline, [note, baseline]);

  useEffect(() => {
    let cancel = false;
    (async () => {
      try {
        const r = await fetch(`/api/offers/${offerId}/note`, { cache: "no-store" });
        if (!r.ok) throw new Error(await r.text());
        const data = await r.json();
        const initial = typeof data?.note === "string" ? data.note : "";
        if (!cancel) {
          setNote(initial);
          setBaseline(initial);
        }
      } catch {
        /* ignore */
      }
    })();
    return () => {
      cancel = true;
    };
  }, [offerId]);

  async function saveNote() {
    try {
      setSaving(true);
      const r = await fetch(`/api/offers/${offerId}/note`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ note }),
      });
      if (!r.ok) throw new Error(await r.text());
      setBaseline(note); // wyzeruj "dirty"
      setMsg("Zapisano notatkę");
      // powiadom innych, że notatka zapisana
      window.dispatchEvent(new CustomEvent("offer-note-saved", { detail: { offerId } }));
      setTimeout(() => setMsg(null), 1200);
    } catch (e: any) {
      setMsg(e?.message || "Błąd zapisu");
    } finally {
      setSaving(false);
    }
  }

  // === GLOBALNE „ZAPISZ WSZYSTKO” z StatusPanel ===
  useEffect(() => {
    const handler = () => {
      if (dirty && !saving) {
        void saveNote();
      }
    };
    return () => window.removeEventListener("offer-save-all", handler as EventListener);
  }, [dirty, saving]);

  return (
    <div className="rounded-lg border border-gray-200 bg-white shadow-sm p-3 space-y-2">
      <div className="font-semibold">Notatki / uwagi</div>
      <textarea
        className={
          "w-full h-28 border rounded p-2 " + (dirty ? "ring-1 ring-yellow-400 bg-yellow-50" : "")
        }
        placeholder="Twoje uwagi do tej oferty…"
        value={note}
        onChange={(e) => setNote(e.target.value)}
      />
      <div className="flex items-center justify-end gap-2">
        <div className={`text-sm ${msg ? "text-gray-700" : "text-gray-500"}`}>{msg}</div>
        <button
          type="button"
          onClick={saveNote}
          disabled={saving}
          className={
            "rounded px-3 py-1 " +
            (dirty
              ? "border border-red-500 text-white bg-red-600 hover:bg-red-700"
              : "border border-gray-300 text-gray-700 bg-white hover:bg-gray-50")
          }
          title={dirty ? "Masz niezapisane zmiany notatki" : "Brak zmian do zapisania"}
        >
          Zapisz notatkę
        </button>
      </div>
    </div>
  );
}
