// src/lib/format.ts
const moneyNF = new Intl.NumberFormat("pl-PL", {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
  useGrouping: true,
});
const percentNF = new Intl.NumberFormat("pl-PL", {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
  useGrouping: true,
});

export function toNumber(value: unknown): number | null {
  if (value == null) return null;
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

export function formatMoney(value: unknown): string {
  const n = toNumber(value);
  return n == null ? "—" : moneyNF.format(n);
}

export function formatPercent(value: unknown): string {
  const n = toNumber(value);
  return n == null ? "—" : `${percentNF.format(n)}%`;
}

export function formatISODate(d?: Date | null): string {
  if (!d) return "—";
  const x = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
  return x.toISOString().slice(0, 10);
}

export const NUMERIC_CLS = "tabular-nums whitespace-nowrap";
