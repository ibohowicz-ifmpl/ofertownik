// src/app/api/offers/[id]/milestones/route.ts
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

const STEP_ORDER = [
  "WYSLANIE",
  "AKCEPTACJA_ZLECENIE",
  "WYKONANIE",
  "PROTOKOL_WYSLANY",
  "ODBIOR_PRAC",
  "PWF",
] as const;
type Step = typeof STEP_ORDER[number];
const ALLOWED = new Set(STEP_ORDER);

// GET — zwraca mapę { STEP: "YYYY-MM-DD" }
export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const ms = await prisma.offerMilestone.findMany({
    where: { offerId: id },
    orderBy: { occurredAt: "asc" },
  });
  const out: Record<string, string> = {};
  for (const m of ms) {
    if (!m.occurredAt) continue;
    const d = new Date(m.occurredAt);
    const x = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
    out[m.step] = x.toISOString().slice(0, 10);
  }
  return Response.json(out);
}

// PUT — waliduje progresję i chronologię
export async function PUT(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return new Response("Invalid JSON", { status: 400 });
  }

  // Wczytaj stan bieżący
  const existing = await prisma.offerMilestone.findMany({
    where: { offerId: id },
  });
  const current: Record<Step, string> = {} as any;
  for (const step of STEP_ORDER) current[step] = "";
  for (const m of existing) {
    if (ALLOWED.has(m.step as Step) && m.occurredAt) {
      const d = new Date(m.occurredAt);
      const x = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
      current[m.step as Step] = x.toISOString().slice(0, 10);
    }
  }

  // Kandydat = current nadpisany wartościami z body (trim)
  const candidate: Record<Step, string> = { ...current };
  for (const [k, v] of Object.entries(body)) {
    if (!ALLOWED.has(k as Step)) continue;
    const s = typeof v === "string" ? v.trim() : "";
    candidate[k as Step] = s;
  }

  // WALIDACJA 1: progresja — nie możesz ustawić późniejszego kroku, gdy wcześniejszy pusty
  for (let i = 0; i < STEP_ORDER.length; i++) {
    const step = STEP_ORDER[i];
    const val = candidate[step];
    if (!val) continue;
    for (let j = 0; j < i; j++) {
      const prev = STEP_ORDER[j];
      if (!candidate[prev]) {
        return new Response(
          `Najpierw uzupełnij etap "${prev}" przed "${step}".`,
          { status: 400 }
        );
      }
    }
  }

  // WALIDACJA 2: chronologia — daty nie maleją
  for (let i = 1; i < STEP_ORDER.length; i++) {
    const prev = candidate[STEP_ORDER[i - 1]];
    const curr = candidate[STEP_ORDER[i]];
    if (prev && curr && curr < prev) {
      return new Response(
        `Data etapu "${STEP_ORDER[i]}" (${curr}) nie może być wcześniejsza niż "${STEP_ORDER[i - 1]}" (${prev}).`,
        { status: 400 }
      );
    }
  }

  // ZAPIS — idąc po kolei
  for (const step of STEP_ORDER) {
    const raw = candidate[step];
    const existingOne = existing.find((m) => m.step === step);
    if (raw) {
      const occurredAt = new Date(`${raw}T00:00:00.000Z`);
      if (Number.isNaN(occurredAt.getTime())) {
        return new Response(`Invalid date for step ${step}`, { status: 400 });
      }
      if (existingOne) {
        await prisma.offerMilestone.update({
          where: { id: existingOne.id },
          data: { occurredAt },
        });
      } else {
        await prisma.offerMilestone.create({
          data: { offerId: id, step, occurredAt },
        });
      }
    } else if (existingOne) {
      await prisma.offerMilestone.delete({ where: { id: existingOne.id } });
    }
  }

  // Zwróć nowy stan
  const ms = await prisma.offerMilestone.findMany({ where: { offerId: id }, orderBy: { occurredAt: "asc" } });
  const out: Record<string, string> = {};
  for (const m of ms) {
    if (!m.occurredAt) continue;
    const d = new Date(m.occurredAt);
    const x = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
    out[m.step] = x.toISOString().slice(0, 10);
  }
  return new Response(JSON.stringify(out), {
    status: 200,
    headers: { "content-type": "application/json; charset=utf-8" },
  });
}
