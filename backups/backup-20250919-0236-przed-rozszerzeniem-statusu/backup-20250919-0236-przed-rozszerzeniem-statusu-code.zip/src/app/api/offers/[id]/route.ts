// src/app/api/offers/[id]/route.ts
import { prisma } from "@/lib/prisma";

function toNum(x: any): number | null {
  if (x === undefined || x === null || x === "") return null;
  const n = Number(String(x).replace(",", "."));
  return Number.isNaN(n) ? null : n;
}
function toStrOrNull(x: any): string | null {
  if (x === undefined || x === null) return null;
  const s = String(x).trim();
  return s === "" ? null : s;
}

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const body = await req.json().catch(() => ({}));
  const {
    vendorOrderNo, contractor, valueNet, wartoscKosztow,
    offerNo, title, authorInitials,
    clientId, clientName
  } = body as Record<string, any>;

  const v = toNum(valueNet);
  const k = toNum(wartoscKosztow);
  const zysk = v != null && k != null ? Number((v - k).toFixed(2)) : null;
  const marza = v != null && k != null && v > 0 ? Number((((v - k) / v) * 100).toFixed(2)) : null;

  // przygotuj dane do update
  const data: any = {
    vendorOrderNo: toStrOrNull(vendorOrderNo),
    contractor: toStrOrNull(contractor),
    valueNet: v,
    wartoscKosztow: k,
    zysk,
    marza,
    offerNo: toStrOrNull(offerNo),
    title: toStrOrNull(title),
    authorInitials: toStrOrNull(authorInitials),
  };

  // zmiana klienta: albo przez clientId, albo przez clientName
  let newClientId: string | null = null;
  const cid = toStrOrNull(clientId);
  const cname = toStrOrNull(clientName);
  if (cid) {
    const exists = await prisma.client.findUnique({ where: { id: cid } });
    if (!exists) return new Response("clientId not found", { status: 400 });
    newClientId = cid;
  } else if (cname) {
    const found = await prisma.client.findFirst({ where: { name: cname } });
    const client = found ?? await prisma.client.create({ data: { name: cname } });
    newClientId = client.id;
  }

  if (newClientId) data.clientId = newClientId;

  await prisma.offer.update({
    where: { id: params.id },
    data,
  });

  return Response.json({ ok: true, clientId: newClientId ?? undefined });
}
