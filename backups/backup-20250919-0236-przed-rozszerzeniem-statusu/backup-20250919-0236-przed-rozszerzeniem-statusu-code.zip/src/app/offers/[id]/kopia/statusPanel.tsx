// src/app/offers/[id]/statusPanel.tsx
"use client";

import { useEffect, useMemo, useState } from "react";
import { formatMoney, NUMERIC_CLS } from "@/lib/format";

type Step =
  | "WYSLANIE"
  | "AKCEPTACJA_ZLECENIE"
  | "WYKONANIE"
  | "PROTOKOL_WYSLANY"
  | "ODBIOR_PRAC"
  | "PWF";

const STEP_ORDER: Step[] = [
  "WYSLANIE",
  "AKCEPTACJA_ZLECENIE",
  "WYKONANIE",
  "PROTOKOL_WYSLANY",
  "ODBIOR_PRAC",
  "PWF",
];

const STEP_LABEL: Record<Step, string> = {
  WYSLANIE: "Wysłano ofertę",
  AKCEPTACJA_ZLECENIE: "Akceptacja / zlecenie",
  WYKONANIE: "Wykonanie",
  PROTOKOL_WYSLANY: "Protokół wysłany",
  ODBIOR_PRAC: "Odebrano prace",
  PWF: "PWF",
};

export default function StatusPanel({ offerId }: { offerId: string }) {
  const [dates, setDates] = useState<Record<string, string>>({});
  const [summary, setSummary] = useState<{ net: number; cost: number }>({
    net: 0,
    cost: 0,
  });

  async function load() {
    try {
      const [d, c] = await Promise.all([
        fetch(`/api/offers/${offerId}/milestones`, { cache: "no-store" }).then(
          (r) => r.json()
        ),
        fetch(`/api/offers/${offerId}/costs`, { cache: "no-store" }).then((r) =>
          r.json()
        ),
      ]);
      setDates(d || {});
      const items = Array.isArray(c?.items) ? c.items : [];
      const cost = items.reduce(
        (acc: number, it: any) => acc + (Number(it?.valueNet) || 0),
        0
      );
      setSummary({ net: 0, cost });
    } catch {}
  }

  useEffect(() => {
    load();
    const onCosts = () => load();
    window.addEventListener("offer-costs-saved", onCosts as EventListener);
    return () => window.removeEventListener("offer-costs-saved", onCosts as EventListener);
  }, [offerId]);

  const latestStep = useMemo(() => {
    for (let i = STEP_ORDER.length - 1; i >= 0; i--) {
      const s = STEP_ORDER[i];
      if (dates[s]) return s;
    }
    return null;
  }, [dates]);

  const statusText = latestStep ? STEP_LABEL[latestStep] : "Brak etapów";
  const statusDate = latestStep ? dates[latestStep] : "";

  const btnPrimary =
    "inline-flex items-center justify-center rounded px-3 py-1 border border-blue-500 text-white bg-blue-600 hover:bg-blue-700";

  return (
    <div className="rounded-lg border border-gray-200 bg-white shadow-sm p-3 space-y-2">
      <div className="font-semibold">Status</div>
      <div className="text-sm text-gray-700">
        Aktualny stan: <span className="font-medium">{statusText}</span>
        {statusDate ? (
          <span> — {new Date(statusDate).toLocaleDateString("pl-PL")}</span>
        ) : null}
      </div>

      <div className="text-sm text-gray-600">
        (Szczegóły marży po lewej — tutaj szybki podgląd kosztów:{" "}
        <span className={`font-medium ${NUMERIC_CLS}`}>{formatMoney(summary.cost)}</span>
        )
      </div>

      <div className="pt-1 flex items-center justify-start">
        <a href="/offers" className={btnPrimary}>
          Wróć do listy ofert
        </a>
      </div>
    </div>
  );
}
