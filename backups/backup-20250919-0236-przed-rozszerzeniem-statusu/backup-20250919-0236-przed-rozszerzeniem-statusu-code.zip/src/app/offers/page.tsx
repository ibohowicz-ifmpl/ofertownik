// src/app/offers/page.tsx
import { prisma } from "@/lib/prisma";
import { formatMoney, formatPercent, NUMERIC_CLS } from "@/lib/format";

export const dynamic = "force-dynamic";

function fmtDate(d?: Date | null) {
  if (!d) return "—";
  const x = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
  return x.toISOString().slice(0, 10);
}
function parseDate(s?: string | null) {
  if (!s) return undefined;
  const d = new Date(s);
  return isNaN(d.getTime()) ? undefined : d;
}
function endOfDay(d?: Date) {
  if (!d) return undefined;
  const e = new Date(d);
  e.setHours(23, 59, 59, 999);
  return e;
}
function toggleDir(current?: string) {
  return current === "asc" ? "desc" : "asc";
}
function buildQuery(base: URLSearchParams, updates: Record<string, string | undefined>) {
  const q = new URLSearchParams(base.toString());
  for (const [k, v] of Object.entries(updates)) {
    if (!v) q.delete(k);
    else q.set(k, v);
  }
  const s = q.toString();
  return s ? `?${s}` : "/offers";
}
function sortLabel(key: string) {
  switch (key) {
    case "offerNo": return "Nr oferty";
    case "title": return "Tytuł";
    case "clientName": return "Odbiorca";
    case "valueNet": return "Wartość";
    case "contractor": return "Wykonawca";
    case "cost": return "Koszt";
    case "profit": return "Zysk";
    case "margin": return "Marża";
    case "createdAt": return "Edycja";
    default: return key;
  }
}

export default async function OffersPage(
  props: { searchParams?: URLSearchParams | Record<string, any> | Promise<URLSearchParams | Record<string, any>> }
) {
  // await (Next 15 może przekazać Promise)
  const raw = (await (props.searchParams as any)) ?? {};

  // Zawsze URLSearchParams (eliminujemy sp["key"])
  const sp: URLSearchParams =
    raw && typeof (raw as any).get === "function"
      ? (raw as URLSearchParams)
      : new URLSearchParams(
          Object.entries(raw as Record<string, any>).flatMap(([k, v]) =>
            v == null ? [] : Array.isArray(v) ? v.map((it) => [k, String(it)]) : [[k, String(v)]]
          )
        );

  const qClient = sp.get("client")?.trim() || undefined;
  const qContractor = sp.get("contractor")?.trim() || undefined;
  const qFrom = parseDate(sp.get("from"));
  const qTo = endOfDay(parseDate(sp.get("to")));
  const qMonth = sp.get("month")?.trim() || undefined; // YYYY-MM

  // Domyślnie: Nr oferty ↑ (od najstarszej)
  const sort = sp.get("sort") || "offerNo";
  const dir = (sp.get("dir") === "desc" ? "desc" : "asc") as "asc" | "desc";

  // WHERE (po SQL, w tym offerMonth)
  const where: any = {};
  if (qClient) where.client = { name: { contains: qClient, mode: "insensitive" } };
  if (qContractor) where.contractor = { contains: qContractor, mode: "insensitive" };
  if (qFrom || qTo) {
    where.milestones = {
      some: {
        step: "WYSLANIE",
        occurredAt: {
          ...(qFrom ? { gte: qFrom } : {}),
          ...(qTo ? { lte: qTo } : {}),
        },
      },
    };
  }
  if (qMonth) where.offerMonth = qMonth;

  // ORDER BY (dla pól nie-liczonych)
  let orderBy: any = undefined;
  if (["offerNo", "title", "contractor", "valueNet", "createdAt"].includes(sort)) {
    orderBy = { [sort]: dir };
  } else if (sort === "clientName") {
    orderBy = { client: { name: dir } };
  }

  // Lista miesięcy (distinct z DB, bez null)
  const monthsRows = await prisma.offer.findMany({
    where: { offerMonth: { not: null } },
    select: { offerMonth: true },
    distinct: ["offerMonth"],
    orderBy: { offerMonth: "desc" },
  } as any);
  const availableMonths = monthsRows.map((r: any) => r.offerMonth as string);

  // Pobranie ofert
  const offersRaw = await prisma.offer.findMany({
    where,
    include: { client: true, milestones: true, costs: true as any },
    ...(orderBy ? { orderBy } : { orderBy: { offerNo: "asc" as const } }), // fallback: rosnąco
  } as any);

  const costSum = (o: any) =>
    typeof o?.wartoscKosztow === "number"
      ? Number(o.wartoscKosztow)
      : Array.isArray(o?.costs)
      ? o.costs.reduce((acc: number, it: any) => acc + (Number(it?.valueNet) || 0), 0)
      : 0;

  // Sort w pamięci tylko dla: koszt, zysk, marża
  const offers = [...offersRaw];
  if (["cost", "profit", "margin"].includes(sort)) {
    offers.sort((a: any, b: any) => {
      const an = Number(a?.valueNet) || 0;
      const bn = Number(b?.valueNet) || 0;
      const ac = costSum(a);
      const bc = costSum(b);
      const ap = an - ac;
      const bp = bn - bc;
      const am = an > 0 ? ap / an : Number.NEGATIVE_INFINITY;
      const bm = bn > 0 ? bp / bn : Number.NEGATIVE_INFINITY;

      let va = 0, vb = 0;
      if (sort === "cost") { va = ac; vb = bc; }
      else if (sort === "profit") { va = ap; vb = bp; }
      else if (sort === "margin") { va = am; vb = bm; }
      return dir === "asc" ? va - vb : vb - va;
    });
  }

  // Agregaty
  const totals = offers.reduce(
    (acc: { net: number; cost: number }, o: any) => {
      const netto = o?.valueNet != null ? Number(o.valueNet) : 0;
      const koszty = costSum(o);
      return { net: acc.net + netto, cost: acc.cost + koszty };
    },
    { net: 0, cost: 0 }
  );
  const totalProfit = totals.net - totals.cost;
  const totalMargin = totals.net > 0 ? (totalProfit / totals.net) * 100 : null;

  // Kolory marży
  const marzaClass = (m: number | null) => {
    if (m == null) return "text-gray-700";
    if (m < 5) return "text-red-600 font-semibold";
    if (m < 14) return "text-amber-500";
    return "text-gray-900";
  };

  const HEADER_BG = "#CFF5F7";
  const ROW_ACCENT = "#B9EEF2";

  // Bazowe query do linków
  const baseQ = new URLSearchParams();
  if (qClient) baseQ.set("client", qClient);
  if (qContractor) baseQ.set("contractor", qContractor);
  if (sp.get("from")) baseQ.set("from", sp.get("from")!);
  if (sp.get("to")) baseQ.set("to", sp.get("to")!);
  if (qMonth) baseQ.set("month", qMonth);

  const headerLink = (key: string, label: string, alignRight = false) => {
    const active = sort === key;
    const nextDir = active ? toggleDir(dir) : "asc";
    const href = buildQuery(baseQ, { sort: key, dir: nextDir });
    const arrow = active ? (dir === "asc" ? "▲" : "▼") : "↕";
    return (
      <a
        href={href}
        className={`inline-flex items-center gap-1 ${alignRight ? "justify-end" : "justify-center"} w-full`}
        title={`Sortuj po: ${label}`}
      >
        <span>{label}</span>
        <span className="text-xs opacity-70">{arrow}</span>
      </a>
    );
  };

  return (
    <main className="h-screen flex flex-col">
      {/* Pasek górny */}
      <div className="sticky top-0 z-40 border-b" style={{ backgroundColor: "#5FD3DA", borderColor: "#34BFC8" }}>
        <div className="px-4 py-3 flex items-center justify-between text-white">
          <div className="flex items-center gap-3">
            <div className="rounded-xl border-2 border-white bg-white px-2 py-1">
              <img src="/offers/logo.svg" alt="Logo" className="h-9 w-auto" />
            </div>
            <h1 className="text-xl font-semibold">Lista ofert</h1>
          </div>

          <a
            href="/offers/new"
            className="inline-block rounded-xl px-4 py-2 border-2 border-white text-[15px]
                      bg-white text-[#009CA6]
                      hover:bg-[#E6FBFC] hover:text-[#009CA6]
                      transition-colors"
          >
            Dodaj ofertę
          </a>
        </div>
      </div>

      {/* Filtry */}
      <div className="px-4 pt-3 pb-2 border-b border-gray-200 bg-white">
        <form method="get" className="flex flex-wrap items-end gap-3 text-[13px]">
          <div>
            <label className="block text-gray-600 mb-1">Klient</label>
            <input name="client" defaultValue={qClient || ""} className="h-8 rounded-md border border-gray-300 px-2" placeholder="np. CBRE" />
          </div>
          <div>
            <label className="block text-gray-600 mb-1">Wykonawca</label>
            <input name="contractor" defaultValue={qContractor || ""} className="h-8 rounded-md border border-gray-300 px-2" placeholder="np. IFM" />
          </div>
          <div>
            <label className="block text-gray-600 mb-1">Wysłanie – od</label>
            <input type="date" name="from" defaultValue={sp.get("from") || ""} className="h-8 rounded-md border border-gray-300 px-2" />
          </div>
          <div>
            <label className="block text-gray-600 mb-1">Wysłanie – do</label>
            <input type="date" name="to" defaultValue={sp.get("to") || ""} className="h-8 rounded-md border border-gray-300 px-2" />
          </div>
          <div>
            <label className="block text-gray-600 mb-1">Miesiąc (z Nr oferty)</label>
            <select name="month" defaultValue={qMonth || ""} className="h-8 rounded-md border border-gray-300 px-2 min-w-[10rem]">
              <option value="">— dowolny —</option>
              {availableMonths.map((m) => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </div>

          <div className="ml-auto flex items-end gap-2">
            <button className="h-8 px-3 rounded-md border border-gray-300 hover:bg-gray-50">Filtruj</button>
            <a href="/offers" className="h-8 px-3 rounded-md border border-gray-300 hover:bg-gray-50 inline-flex items-center">Wyczyść</a>
          </div>
        </form>

        {/* Chipy aktywnych filtrów + sort */}
        {(qClient || qContractor || sp.get("from") || sp.get("to") || qMonth || sort !== "offerNo" || dir !== "asc") && (
          <div className="mt-2 flex flex-wrap gap-2 text-[12px]">
            {qClient && (
              <a href={buildQuery(baseQ, { client: "" })} className="inline-flex items-center gap-1 px-2 py-1 rounded-md border border-gray-300 bg-gray-50 hover:bg-gray-100" title="Usuń filtr: Klient">
                <span>Klient:</span><strong>{qClient}</strong><span aria-hidden>×</span>
              </a>
            )}
            {qContractor && (
              <a href={buildQuery(baseQ, { contractor: "" })} className="inline-flex items-center gap-1 px-2 py-1 rounded-md border border-gray-300 bg-gray-50 hover:bg-gray-100" title="Usuń filtr: Wykonawca">
                <span>Wykonawca:</span><strong>{qContractor}</strong><span aria-hidden>×</span>
              </a>
            )}
            {sp.get("from") && (
              <a href={buildQuery(baseQ, { from: "" })} className="inline-flex items-center gap-1 px-2 py-1 rounded-md border border-gray-300 bg-gray-50 hover:bg-gray-100" title="Usuń filtr: Od">
                <span>Od:</span><strong>{sp.get("from")}</strong><span aria-hidden>×</span>
              </a>
            )}
            {sp.get("to") && (
              <a href={buildQuery(baseQ, { to: "" })} className="inline-flex items-center gap-1 px-2 py-1 rounded-md border border-gray-300 bg-gray-50 hover:bg-gray-100" title="Usuń filtr: Do">
                <span>Do:</span><strong>{sp.get("to")}</strong><span aria-hidden>×</span>
              </a>
            )}
            {qMonth && (
              <a href={buildQuery(baseQ, { month: "" })} className="inline-flex items-center gap-1 px-2 py-1 rounded-md border border-gray-300 bg-gray-50 hover:bg-gray-100" title="Usuń filtr: Miesiąc">
                <span>Miesiąc:</span><strong>{qMonth}</strong><span aria-hidden>×</span>
              </a>
            )}
            {(sort !== "offerNo" || dir !== "asc") && (
              <a href={buildQuery(baseQ, { sort: "", dir: "" })} className="inline-flex items-center gap-1 px-2 py-1 rounded-md border border-gray-300 bg-white hover:bg-gray-50" title="Usuń sortowanie (wróć do: Nr oferty ↑)">
                <span>Sort:</span>
                <strong>{sortLabel(sort)}</strong>
                <span className="opacity-70">{dir === "asc" ? "▲" : "▼"}</span>
                <span aria-hidden>×</span>
              </a>
            )}
            <a href="/offers" className="inline-flex items-center gap-1 px-2 py-1 rounded-md border border-gray-300 bg-white hover:bg-gray-50" title="Wyczyść wszystkie">
              Wyczyść wszystko
            </a>
          </div>
        )}
      </div>

      {/* Tabela */}
      <div className="p-4 flex-1 min-h-0">
        <div className="rounded-lg border border-gray-200 bg-white shadow-sm overflow-hidden h-full flex flex-col">
          <div className="overflow-auto flex-1 min-h-0">
            <table className="min-w-full text-[13px] border-separate border-spacing-0">
              <thead>
                {/* RZĄD 1 */}
                <tr className="text-center text-gray-700">
                  <th className="py-2 pr-2 whitespace-nowrap border-r border-gray-200 sticky z-30 h-10 w-[8.5rem] align-middle" style={{ top: 0, backgroundColor: "#CFF5F7" }} rowSpan={2}>
                    {headerLink("offerNo", "Nr oferty")}
                  </th>
                  <th className="py-2 pr-4 sticky z-30 h-10 max-w-[52rem] align-middle" style={{ top: 0, backgroundColor: "#CFF5F7" }} rowSpan={2}>
                    {headerLink("title", "Tytuł")}
                  </th>
                  <th className="py-2 pr-3 whitespace-nowrap sticky z-30 h-10 align-middle" style={{ top: 0, backgroundColor: "#CFF5F7" }} rowSpan={2}>
                    {headerLink("clientName", "Odbiorca")}
                  </th>
                  <th className="py-2 pr-3 whitespace-nowrap sticky z-30 h-10 align-middle" style={{ top: 0, backgroundColor: "#CFF5F7" }} rowSpan={2}>
                    {headerLink("valueNet", "Wartość", true)}
                  </th>

                  {/* Daty etapów */}
                  <th className="py-2 px-2 text-[12px] sticky z-30 h-10" style={{ top: 0, backgroundColor: "#CFF5F7" }} colSpan={6}>
                    Daty etapów
                  </th>

                  <th className="py-2 pr-3 whitespace-nowrap hidden sticky z-30 h-10" style={{ top: 0, backgroundColor: "#CFF5F7" }} rowSpan={2}>
                    Numer zlecenia
                  </th>
                  <th className="py-2 pr-3 whitespace-nowrap sticky z-30 h-10 align-middle" style={{ top: 0, backgroundColor: "#CFF5F7" }} rowSpan={2}>
                    {headerLink("contractor", "Wykonawca")}
                  </th>

                  {/* Analityka */}
                  <th className="py-2 pr-3 whitespace-nowrap border-l border-gray-200 sticky z-30 h-10 align-middle" style={{ top: 0, backgroundColor: "#CFF5F7" }} rowSpan={2}>
                    {headerLink("cost", "Koszt", true)}
                  </th>
                  <th className="py-2 pr-3 whitespace-nowrap border-l border-gray-200 sticky z-30 h-10 align-middle" style={{ top: 0, backgroundColor: "#CFF5F7" }} rowSpan={2}>
                    {headerLink("profit", "Zysk", true)}
                  </th>
                  <th className="py-2 pr-3 whitespace-nowrap border-l border-gray-200 sticky z-30 h-10 align-middle" style={{ top: 0, backgroundColor: "#CFF5F7" }} rowSpan={2}>
                    {headerLink("margin", "Marża", true)}
                  </th>
                  <th className="py-2 pr-0 whitespace-nowrap sticky z-30 h-10 align-middle" style={{ top: 0, backgroundColor: "#CFF5F7" }} rowSpan={2}>
                    {headerLink("createdAt", "Edycja")}
                  </th>
                </tr>

                {/* RZĄD 2 (etykiety dat) */}
                <tr className="text-center text-gray-700 border-b-2" style={{ borderColor: "#B9EEF2" }}>
                  <th className="py-2 pr-1 w-[5.25rem] text-[11px] sticky z-20 h-10" style={{ top: 40, backgroundColor: "#CFF5F7" }}>Wysłanie</th>
                  <th className="py-2 pr-1 w-[5.25rem] text-[11px] sticky z-20 h-10" style={{ top: 40, backgroundColor: "#CFF5F7" }}>Akceptacja</th>
                  <th className="py-2 pr-1 w-[5.25rem] text-[11px] sticky z-20 h-10" style={{ top: 40, backgroundColor: "#CFF5F7" }}>Wykonanie</th>
                  <th className="py-2 pr-1 w-[5.25rem] text-[11px] sticky z-20 h-10" style={{ top: 40, backgroundColor: "#CFF5F7" }}>Protokół</th>
                  <th className="py-2 pr-1 w-[5.25rem] text-[11px] sticky z-20 h-10" style={{ top: 40, backgroundColor: "#CFF5F7" }}>Odbiór prac</th>
                  <th className="py-2 pr-1 w-[5.25rem] text-[11px] sticky z-20 h-10" style={{ top: 40, backgroundColor: "#CFF5F7" }}>PWF</th>
                </tr>
              </thead>

              <tbody>
                {offers.map((o: any) => {
                  const netto = o?.valueNet != null ? Number(o.valueNet) : 0;
                  const koszty = costSum(o);
                  const zysk = netto - koszty;
                  const marza = netto > 0 ? (zysk / netto) * 100 : null;

                  const zyskCls = zysk < 0 ? "text-red-600" : zysk === 0 ? "text-gray-700" : "text-gray-900";
                  const marzaCls = marzaClass(marza);

                  return (
                    <tr key={o.id} className="align-top border-b hover:bg-[#E6FBFC]" style={{ borderColor: "#B9EEF2" }}>
                      {/* Nr oferty */}
                      <td className="py-2 pr-2 pl-2 whitespace-nowrap bg-gray-50 border-r border-gray-200 w-[8.5rem]">
                        {o.offerNo || "—"}
                      </td>

                      {/* Tytuł */}
                      <td className="py-2 pr-4 pl-2 max-w-[52rem]">
                        <div className="leading-snug" style={{ display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }} title={o.title || ""}>
                          {o.title || "—"}
                        </div>
                      </td>

                      {/* Odbiorca */}
                      <td className="py-2 pr-3 whitespace-nowrap uppercase">{o.client?.name || "—"}</td>

                      {/* Wartość */}
                      <td className={`py-2 pr-3 whitespace-nowrap text-right ${NUMERIC_CLS}`}>{formatMoney(netto)}</td>

                      {/* Daty (wyśrodkowane) */}
                      <td className="py-2 pr-1 w-[5.25rem] whitespace-nowrap bg-gray-50 text-center">{fmtDate(o.milestones?.find((m:any)=>m.step==="WYSLANIE")?.occurredAt)}</td>
                      <td className="py-2 pr-1 w-[5.25rem] whitespace-nowrap bg-gray-50 text-center">{fmtDate(o.milestones?.find((m:any)=>m.step==="AKCEPTACJA_ZLECENIE")?.occurredAt)}</td>
                      <td className="py-2 pr-1 w-[5.25rem] whitespace-nowrap bg-gray-50 text-center">{fmtDate(o.milestones?.find((m:any)=>m.step==="WYKONANIE")?.occurredAt)}</td>
                      <td className="py-2 pr-1 w-[5.25rem] whitespace-nowrap bg-gray-50 text-center">{fmtDate(o.milestones?.find((m:any)=>m.step==="PROTOKOL_WYSLANY")?.occurredAt)}</td>
                      <td className="py-2 pr-1 w-[5.25rem] whitespace-nowrap bg-gray-50 text-center">{fmtDate(o.milestones?.find((m:any)=>m.step==="ODBIOR_PRAC")?.occurredAt)}</td>
                      <td className="py-2 pr-1 w-[5.25rem] whitespace-nowrap bg-gray-50 text-center">{fmtDate(o.milestones?.find((m:any)=>m.step==="PWF")?.occurredAt)}</td>

                      {/* Ukryty numer zlecenia */}
                      <td className="py-2 pr-3 whitespace-nowrap hidden">{o.vendorOrderNo || "—"}</td>

                      {/* Wykonawca */}
                      <td className="py-2 pr-3 pl-2 whitespace-nowrap">{o.contractor || "—"}</td>

                      {/* Analityka */}
                      <td className={`py-2 pr-3 whitespace-nowrap text-right bg-gray-50 border-l border-gray-200 ${NUMERIC_CLS}`}>{formatMoney(koszty)}</td>
                      <td className={`py-2 pr-3 whitespace-nowrap text-right bg-gray-50 border-l border-gray-200 ${NUMERIC_CLS} ${zyskCls}`}>{formatMoney(zysk)}</td>
                      <td className={`py-2 pr-3 whitespace-nowrap text-right bg-gray-50 border-l border-gray-200 ${NUMERIC_CLS} ${marzaCls}`}>{formatPercent(marza)}</td>

                      {/* Edycja */}
                      <td className="py-2 pr-0 whitespace-nowrap text-right">
                        <a href={`/offers/${o.id}/edit`} className="inline-block rounded px-3 py-1 border border-blue-400 text-blue-700 bg-blue-50 hover:bg-blue-100">Edytuj</a>
                      </td>
                    </tr>
                  );
                })}
              </tbody>

              {/* SUMA */}
              <tfoot className="bg-gray-50 text-gray-900 font-semibold">
                <tr>
                  <td className="py-2 pr-2 pl-2 w-[8.5rem]">—</td>
                  <td className="py-2 pr-4 pl-2" colSpan={2}>Razem</td>
                  <td className={`py-2 pr-3 text-right ${NUMERIC_CLS}`}>{formatMoney(totals.net)}</td>
                  <td colSpan={6}></td>
                  <td className="hidden"></td>
                  <td></td>
                  <td className={`py-2 pr-3 text-right ${NUMERIC_CLS}`}>{formatMoney(totals.cost)}</td>
                  <td className={`py-2 pr-3 text-right ${NUMERIC_CLS} ${totalProfit < 0 ? "text-red-600" : ""}`}>{formatMoney(totalProfit)}</td>
                  <td className={`py-2 pr-3 text-right ${NUMERIC_CLS} ${marzaClass(totalMargin)}`}>{formatPercent(totalMargin)}</td>
                  <td></td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </div>
    </main>
  );
}
