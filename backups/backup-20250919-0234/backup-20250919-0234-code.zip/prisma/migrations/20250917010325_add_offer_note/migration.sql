-- AlterTable
ALTER TABLE "public"."Offer" ADD COLUMN     "note" TEXT;
