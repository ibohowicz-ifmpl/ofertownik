// src/app/offers/[id]/editPanel.tsx
"use client";

import { useEffect, useMemo, useState } from "react";
import { toNumber, formatMoney, formatPercent, NUMERIC_CLS } from "@/lib/format";

// usuń zwykłe i niełamliwe spacje z kwot
const SPACE_RE = /[ \u00A0\u202F]/g;

type EditPanelProps = {
  id: string;
  initialFields: {
    offerNo: string;
    title: string;
    authorInitials: string;
    vendorOrderNo: string;
    contractor: string;
    valueNet: string; // liczba jako string lub ""
    wartoscKosztow?: string; // tylko info; nie edytujemy tutaj
  };
  initialDates: Record<string, string>;
  initialClient: { id: string; name: string };
};

function formatPL2(text: string): string {
  const n = toNumber(text.replace?.(SPACE_RE, "").replace?.(",", ".") ?? text);
  return n == null ? text || "" : formatMoney(n);
}

const STEP_ORDER = [
  "WYSLANIE",
  "AKCEPTACJA_ZLECENIE",
  "WYKONANIE",
  "PROTOKOL_WYSLANY",
  "ODBIOR_PRAC",
  "PWF",
] as const;
type Step = typeof STEP_ORDER[number];

function normalizeDateInput(v: any): string | "" {
  if (!v) return "";
  try {
    if (/^\d{4}-\d{2}-\d{2}$/.test(String(v))) return String(v);
    const d = new Date(String(v));
    if (isNaN(d.getTime())) return "";
    return d.toISOString().slice(0, 10);
  } catch {
    return "";
  }
}

function toDatesRecordLoose(data: any): Record<string, string> {
  const arr = Array.isArray(data?.items)
    ? data.items
    : Array.isArray(data?.milestones)
    ? data.milestones
    : null;
  if (arr) {
    const out: Record<string, string> = {};
    for (const it of arr) {
      const step = it?.step || it?.name || it?.code;
      const when =
        it?.occurredAt ??
        it?.occurred_at ??
        it?.date ??
        it?.occurred ??
        it?.at;
      if (step) out[step] = normalizeDateInput(when);
    }
    return out;
  }
  if (data && typeof data === "object") {
    const out: Record<string, string> = {};
    for (const k of STEP_ORDER) {
      const v = (data as any)[k];
      out[k] = normalizeDateInput(v);
    }
    return out;
  }
  return {};
}

export default function EditPanel({
  id,
  initialFields,
  initialDates,
  initialClient,
}: EditPanelProps) {
  const initialFieldsFormatted = useMemo(() => {
    return { ...initialFields, valueNet: formatPL2(initialFields.valueNet || "") };
  }, [initialFields]);

  const initialDatesNormalized = useMemo(() => {
    const out: Record<string, string> = {};
    for (const k of STEP_ORDER) {
      out[k] = normalizeDateInput((initialDates || {})[k]);
    }
    return out;
  }, [initialDates]);

  // --- Pola oferty ---
  const [editMode, setEditMode] = useState(false);
  const [fields, setFields] = useState({ ...initialFieldsFormatted });
  // 🔧 NOWE: baseline dla pól, względem którego liczymy „brud”
  const [fieldsBaseline, setFieldsBaseline] = useState({ ...initialFieldsFormatted });

  // przy zmianie oferty resetuj wszystko
  useEffect(() => {
    const next = { ...initialFieldsFormatted };
    setFields(next);
    setFieldsBaseline(next); // baseline = aktualny stan startowy
    setEditMode(false);
  }, [id, initialFieldsFormatted]);

  const fieldsDirty =
    fields.offerNo !== fieldsBaseline.offerNo ||
    fields.title !== fieldsBaseline.title ||
    fields.authorInitials !== fieldsBaseline.authorInitials ||
    fields.vendorOrderNo !== fieldsBaseline.vendorOrderNo ||
    fields.contractor !== fieldsBaseline.contractor ||
    (fields.valueNet || "") !== (fieldsBaseline.valueNet || "");

  // --- Daty etapów ---
  const [dates, setDates] = useState<Record<string, string>>({
    ...initialDatesNormalized,
  });
  const [savedDates, setSavedDates] = useState<Record<string, string>>({
    ...initialDatesNormalized,
  });

  const dirtyDateKeys = STEP_ORDER.filter(
    (k) => (dates[k] || "") !== (savedDates[k] || "")
  );
  const anyDatesDirty = dirtyDateKeys.length > 0;

  const [saveMsg, setSaveMsg] = useState<{
    text: string;
    type: "success" | "error";
  } | null>(null);

  // --- SUMA KOSZTÓW ---
  const [costsSum, setCostsSum] = useState<number>(0);

  async function refreshCostsSum() {
    try {
      const r = await fetch(`/api/offers/${id}/costs`, { cache: "no-store" });
      if (!r.ok) return;
      const data = await r.json();
      const items = Array.isArray(data?.items) ? data.items : [];
      const sum = items.reduce(
        (acc: number, it: any) => acc + (Number(it?.valueNet) || 0),
        0
      );
      setCostsSum(sum);
    } catch {}
  }

  async function refreshDatesFromApi() {
    try {
      const r = await fetch(`/api/offers/${id}/milestones`, {
        cache: "no-store",
      });
      if (!r.ok) return;
      const data = await r.json();
      const rec = toDatesRecordLoose(data);
      setDates(rec);
      setSavedDates(rec);
    } catch {}
  }

  useEffect(() => {
    refreshCostsSum();
    refreshDatesFromApi();
  }, [id]);

  // nasłuch z panelu kosztów
  useEffect(() => {
    function onCostsSaved(e: any) {
      try {
        const det = e?.detail || {};
        if (det.offerId === id) {
          if (typeof det.sumNet === "number") {
            setCostsSum(det.sumNet);
          } else {
            refreshCostsSum();
          }
        }
      } catch {}
    }
    window.addEventListener("offer-costs-saved", onCostsSaved);
    return () => window.removeEventListener("offer-costs-saved", onCostsSaved);
  }, [id]);

  // obliczenia marży
  const valueNetNumber = (() => {
    const raw = (fields.valueNet || "").replace(SPACE_RE, "").replace(",", ".");
    const n = Number(raw);
    return Number.isFinite(n) ? n : 0;
  })();
  const profit = Math.max(0, valueNetNumber - costsSum);
  const margin = valueNetNumber > 0 ? (profit / valueNetNumber) * 100 : 0;
  const marginClass =
    margin > 0
      ? margin < 5
        ? "text-red-600"
        : margin < 14
        ? "text-orange-500"
        : "text-gray-900"
      : "text-gray-900";

  // ✅ ZAPIS PÓL — po sukcesie:
  // - normalizujemy valueNet,
  // - baseline = znormalizowane fields,
  // - wyłączamy tryb edycji -> przycisk „Zapisz dane” wraca do neutralnego.
  async function saveFieldsOnly() {
    try {
      const payloadFields = {
        offerNo: fields.offerNo.trim() || null,
        title: fields.title.trim() || null,
        authorInitials: fields.authorInitials.trim() || null,
        vendorOrderNo: fields.vendorOrderNo.trim() || null,
        contractor: fields.contractor.trim() || null,
        valueNet:
          fields.valueNet.trim() === ""
            ? null
            : Number(fields.valueNet.replace(SPACE_RE, "").replace(",", ".")),
      };
      const r1 = await fetch(`/api/offers/${id}/fields`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payloadFields),
      });
      if (!r1.ok) throw new Error(await r1.text());

      // znormalizuj valueNet do 2 miejsc i zapisz jako baseline
      const normalized = {
        ...fields,
        valueNet: formatPL2(fields.valueNet || ""),
      };
      setFields(normalized);
      setFieldsBaseline(normalized); // 🔧 baseline = zapisany stan
      setEditMode(false);            // 🔧 wyłącz edycję

      setSaveMsg({ text: "Zapisano dane oferty.", type: "success" });
      setTimeout(() => setSaveMsg(null), 1500);
    } catch (e: any) {
      setSaveMsg({ text: e?.message || "Błąd zapisu danych.", type: "error" });
      setTimeout(() => setSaveMsg(null), 2500);
    }
  }

  // zapisywanie dat
  async function saveDatesOnly() {
    try {
      if (!anyDatesDirty) return;

      const payload: Record<string, string | null> = {};
      for (const step of STEP_ORDER) {
        payload[step] = dates[step] ? dates[step] : null;
      }

      const res = await fetch(`/api/offers/${id}/milestones`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || `HTTP ${res.status} ${res.statusText}`);
      }

      await refreshDatesFromApi();
      setSaveMsg({ text: "Zapisano daty etapów.", type: "success" });
      setTimeout(() => setSaveMsg(null), 1500);
    } catch (e: any) {
      setSaveMsg({ text: e?.message || "Błąd zapisu dat.", type: "error" });
      setTimeout(() => setSaveMsg(null), 3500);
    }
  }

  const headerClientName = initialClient?.name || "—";

  return (
    <div className="space-y-4">
      {/* Toast */}
      {saveMsg && (
        <div
          role="status"
          aria-live="polite"
          className={`fixed bottom-4 right-4 z-50 rounded px-3 py-2 text-sm shadow
            ${saveMsg.type === "success" ? "bg-green-600 text-white" : "bg-red-600 text-white"}`}
        >
          {saveMsg.text}
        </div>
      )}

      {/* Nagłówek */}
      <div className="text-blue-700">
        <div className="text-lg md:text-xl font-semibold leading-snug break-words">
          {fields.offerNo || "—"}
        </div>
        <div className="text-base md:text-lg font-medium leading-snug break-words">
          {(fields.title || "—") + " — " + (headerClientName || "—")}
        </div>
      </div>

      {/* Dane oferty */}
      <div className="rounded-lg border border-gray-200 bg-white shadow-sm p-3">
        <div className="flex items-center justify-between mb-2">
          <div className="font-semibold">Dane oferty</div>
          <button
            onClick={() => setEditMode((v) => !v)}
            className={`rounded px-3 py-1 border ${
              editMode
                ? "border-blue-500 text-blue-700 bg-blue-50"
                : "border-gray-300 text-gray-700 bg-white"
            }`}
          >
            Edycja
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <label className="grid gap-1">
            <span className="text-sm text-gray-700">Nr oferty</span>
            <input
              className={`border rounded px-2 py-1 ${
                editMode && fields.offerNo !== fieldsBaseline.offerNo
                  ? "ring-1 ring-yellow-400 bg-yellow-50"
                  : ""
              }`}
              value={fields.offerNo}
              onChange={(e) => setFields((s) => ({ ...s, offerNo: e.target.value }))}
              disabled={!editMode}
            />
          </label>

          <label className="grid gap-1">
            <span className="text-sm text-gray-700">Autor (inicjały)</span>
            <input
              className={`border rounded px-2 py-1 ${
                editMode && fields.authorInitials !== fieldsBaseline.authorInitials
                  ? "ring-1 ring-yellow-400 bg-yellow-50"
                  : ""
              }`}
              value={fields.authorInitials}
              onChange={(e) => setFields((s) => ({ ...s, authorInitials: e.target.value }))}
              disabled={!editMode}
            />
          </label>

          <label className="md:col-span-2 grid gap-1">
            <span className="text-sm text-gray-700">Tytuł</span>
            <input
              className={`border rounded px-2 py-1 ${
                editMode && fields.title !== fieldsBaseline.title
                  ? "ring-1 ring-yellow-400 bg-yellow-50"
                  : ""
              }`}
              value={fields.title}
              onChange={(e) => setFields((s) => ({ ...s, title: e.target.value }))}
              disabled={!editMode}
            />
          </label>

          <label className="grid gap-1">
            <span className="text-sm text-gray-700">Wykonawca</span>
            <input
              className={`border rounded px-2 py-1 ${
                editMode && fields.contractor !== fieldsBaseline.contractor
                  ? "ring-1 ring-yellow-400 bg-yellow-50"
                  : ""
              }`}
              value={fields.contractor}
              onChange={(e) => setFields((s) => ({ ...s, contractor: e.target.value }))}
              disabled={!editMode}
            />
          </label>

          <label className="grid gap-1">
            <span className="text-sm text-gray-700">Wartość netto</span>
            <input
              className={`border rounded px-2 py-1 text-right ${NUMERIC_CLS} ${
                editMode &&
                (fields.valueNet || "") !== (fieldsBaseline.valueNet || "")
                  ? "ring-1 ring-yellow-400 bg-yellow-50"
                  : ""
              }`}
              inputMode="decimal"
              value={fields.valueNet}
              onBlur={(e) => {
                const n = Number(
                  (e.currentTarget.value || "").replace(SPACE_RE, "").replace(",", ".")
                );
                if (Number.isFinite(n)) {
                  const f = formatMoney(n);
                  setFields((prev) => ({ ...prev, valueNet: f }));
                }
              }}
              onFocus={(e) => {
                const n = Number(
                  (fields.valueNet || "").replace(SPACE_RE, "").replace(",", ".")
                );
                const raw = Number.isFinite(n)
                  ? String(n).replace(".", ",")
                  : fields.valueNet || "";
                e.currentTarget.value = raw;
              }}
              onChange={(e) => setFields((s) => ({ ...s, valueNet: e.target.value }))}
              disabled={!editMode}
              placeholder="0,00"
            />
          </label>

          {/* LEWA: Numer zlecenia */}
          <label className="grid gap-1">
            <span className="text-sm text-gray-700">Numer zlecenia</span>
            <input
              className={`border rounded px-2 py-1 ${
                editMode &&
                fields.vendorOrderNo !== fieldsBaseline.vendorOrderNo
                  ? "ring-1 ring-yellow-400 bg-yellow-50"
                  : ""
              }`}
              value={fields.vendorOrderNo}
              onChange={(e) => setFields((s) => ({ ...s, vendorOrderNo: e.target.value }))}
              disabled={!editMode}
            />
          </label>

          {/* PRAWA: Marża */}
          <label className="grid gap-1">
            <span className="text-sm text-gray-700">Marża</span>
            <div className={`border rounded px-2 py-1 bg-gray-50 text-right font-semibold ${marginClass} ${NUMERIC_CLS}`}>
              {valueNetNumber > 0 ? formatPercent(margin) : "—"}
            </div>
          </label>
        </div>

        {/* PRZYCISK ZAPISU DANYCH */}
        <div className="mt-3 flex items-center justify-end">
          <button
            onClick={saveFieldsOnly}
            disabled={!editMode}
            className={
              "rounded px-3 py-1 " +
              (editMode && fieldsDirty
                ? "border border-red-500 text-white bg-red-600 hover:bg-red-700"
                : "border border-gray-300 text-gray-700 bg-white hover:bg-gray-50")
            }
            title={
              !editMode
                ? "Włącz edycję, aby zapisać"
                : fieldsDirty
                ? "Zapisz zmiany pól"
                : "Brak zmian do zapisania"
            }
          >
            Zapisz dane
          </button>
        </div>
      </div>

      {/* Daty etapów */}
      <div className="rounded-lg border border-gray-200 bg-white shadow-sm p-3">
        <div className="font-semibold mb-2">Daty etapów</div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {STEP_ORDER.map((step, idx) => {
            const enabled = idx === 0 ? true : Boolean(dates[STEP_ORDER[idx - 1]]);
            const dirty = (dates[step] || "") !== (savedDates[step] || "");
            const min =
              idx > 0 && dates[STEP_ORDER[idx - 1]]
                ? dates[STEP_ORDER[idx - 1]]
                : undefined;
            const label =
              step === "WYSLANIE"
                ? "Data wysłania"
                : step === "AKCEPTACJA_ZLECENIE"
                ? "Data akceptacji"
                : step === "WYKONANIE"
                ? "Data wykonania"
                : step === "PROTOKOL_WYSLANY"
                ? "Data protokołu"
                : step === "ODBIOR_PRAC"
                ? "Data odbioru prac"
                : "Data PWF";

            return (
              <label key={step} className="grid gap-1">
                <span
                  className={`text-sm ${dirty ? "text-amber-700 font-medium" : "text-gray-700"} ${
                    !enabled ? "opacity-70" : ""
                  }`}
                >
                  {label}
                </span>
                <input
                  type="date"
                  className={`border rounded px-2 py-1 ${
                    dirty ? "ring-1 ring-yellow-400 bg-yellow-50 " : ""
                  } ${!enabled ? "bg-gray-50 text-gray-500 cursor-not-allowed " : ""}`}
                  value={dates[step] || ""}
                  onChange={(e) =>
                    setDates((m) => ({ ...m, [step]: e.target.value }))
                  }
                  disabled={!enabled}
                  min={min}
                  title={enabled ? "" : "Najpierw uzupełnij wcześniejsze etapy"}
                />
              </label>
            );
          })}
        </div>

        {/* PRZYCISK ZAPISU DAT */}
        <div className="mt-3 flex items-center justify-end gap-2">
          <div className="text-sm text-gray-600">
            {anyDatesDirty ? `Niezapisane daty: ${dirtyDateKeys.length}` : ""}
          </div>
          <button
            onClick={saveDatesOnly}
            disabled={!anyDatesDirty}
            className={
              "rounded px-3 py-1 " +
              (anyDatesDirty
                ? "border border-red-500 text-white bg-red-600 hover:bg-red-700"
                : "border border-gray-300 text-gray-700 bg-white hover:bg-gray-50")
            }
            title={anyDatesDirty ? "Zapisz zmienione daty" : "Brak zmian do zapisania"}
          >
            Zapisz daty
          </button>
        </div>
      </div>
    </div>
  );
}
