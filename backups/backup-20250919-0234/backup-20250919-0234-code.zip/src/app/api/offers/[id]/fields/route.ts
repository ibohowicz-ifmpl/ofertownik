// src/app/api/offers/[id]/fields/route.ts
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

type Body = {
  offerNo?: string | null;
  title?: string | null;
  authorInitials?: string | null;
  vendorOrderNo?: string | null;
  contractor?: string | null;
  valueNet?: number | null;
};

export async function PUT(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  if (!id) return new Response("Missing id", { status: 400 });

  let body: Body = {};
  try {
    body = await req.json();
  } catch {
    return new Response("Invalid JSON", { status: 400 });
  }

  // sanitizacja
  const clean = (v: unknown) =>
    v === null || v === undefined ? null : String(v).trim() || null;

  const offerNo       = clean(body.offerNo);
  const title         = clean(body.title);
  const authorInitials= clean(body.authorInitials);
  const vendorOrderNo = clean(body.vendorOrderNo);
  const contractor    = clean(body.contractor);

  let valueNet: number | null = null;
  if (body.valueNet === null || body.valueNet === undefined) {
    valueNet = null;
  } else {
    const num = Number(body.valueNet);
    if (!Number.isFinite(num)) return new Response("Invalid valueNet", { status: 400 });
    valueNet = num;
  }

  try {
    const updated = await prisma.offer.update({
      where: { id },
      data: {
        offerNo,
        title,
        authorInitials,
        vendorOrderNo,
        contractor,
        valueNet,
      },
      select: {
        id: true,
        offerNo: true,
        title: true,
        authorInitials: true,
        vendorOrderNo: true,
        contractor: true,
        valueNet: true,
      },
    });

    return Response.json(updated);
  } catch (e: any) {
    return new Response(e?.message || "Update failed", { status: 500 });
  }
}
