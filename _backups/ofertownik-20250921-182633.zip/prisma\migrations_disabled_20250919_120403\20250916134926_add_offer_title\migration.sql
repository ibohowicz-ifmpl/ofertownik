-- AlterTable
ALTER TABLE "public"."Offer" ADD COLUMN     "title" TEXT;
